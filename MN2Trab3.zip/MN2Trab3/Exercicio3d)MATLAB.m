hold on
uh1=mef(1/10)
uh2=mef(1/20)
uh3=mef(1/40)
hold off

function [uh]= mef(h)
n = (1/h)-1; 
x = (0:h:1); 
T=1 ; 
k=0.1;
f = @(x)  (1+ sin(4*pi*x))/T;
alpha=k/T;
% m�todo num�rico
e = ones(n,1);
M = (h/6)*spdiags([e 4*e e],-1:1,n,n);
K = (1/h)*spdiags([-e 2*e -e],-1:1,n,n);
A = K+alpha*M;
b = h*f(x(2:end-1));
uh = A\b'; uh = [0; uh; 0];
% gr�fico
plot(x,uh,'LineWidth',2);
legend('h=1/10','h=1/20', 'h=1/40'); title(['MEF']);

end