clc; clear; close all;

t = [0; 2; 3; 4; 5; 6; 7; 8; 9; 10; 11; 12; 13; 14; 15; 16; 17; 18; 19; 20; 21; 22; 23; 24; 25];
P = [2; 14; 34; 56; 94; 189; 266; 330; 416; 507; 580; 610; 513; 593; 557; 560; 522; 565; 517; 500; 585; 500; 495; 525; 510];
%x é o vetor dos parâmetros (x(1)=k e x(2)=r)
%aproximacao inicial
x=[550 ;0.75];

%método gauss newton para MQ não lineares
k=0;
kmax=50;
erro=1;

while((k<=kmax) && (erro>=1e-10))
    k=k+1;
   
    R=FuncResidual(x,t,P);
    J=Jacobiana(x,t);
    x=x-((J')*J)\((J')*R);
      
    
    
end
x

f=@(t) x(1)./(1+(((x(1)-2)/2)*exp(-t*x(2)))); 
fplot(f,[0 30],'LineWidth',2)
hold on
plot(t,P,'*k','LineWidth',2)




function R = FuncResidual(x,t,P)
% Definicao de Funcao Residual 
    R=zeros(25,1);
    for i=1:25
        R(i)=x(1)/(1+((x(1)-2)/2)*exp(-x(2)*t(i))) - P(i);
    end
end

function J = Jacobiana(x,t)
% Definicao da Jacobiana da Funcao Residual
    J=zeros(25,2);
    for i=1:25
        J(i,1)=4*(1-exp(-x(2)*t(i)))/((2+(x(1)-2)*exp(-x(2)*t(i)))^(2));
        J(i,2)=2*t(i)*x(1)*(x(1)-2)*exp(-x(2)*t(i))/(2+(x(1)-2)*exp(-x(2)*t(i)))^2;
    end
end
