format long
%aproximação inicial
x=0;
%número máximo de iterações
itermax=30;
%"distância" entre iterações consecutivas/erro
e=1;
%vetor de iterações
x_i=x;
%inicializar número de iterações
n=0;
while e>=1e-30 && n<=itermax
    
    y=x-(cos(12*x)+x-x^2)/(1-2*x-12*sin(12*x));
    x_i=[x_i;y];
    e=abs(y-x)

    x=y;
    n=n+1;
end


